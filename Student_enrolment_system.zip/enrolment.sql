-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2018 at 07:49 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrolment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_phone`, `created_at`, `updated_at`) VALUES
(1, 'hasan mahmud', 'hasan@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01845124548', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_07_21_055916_create_admin_tbl_table', 1),
(2, '2018_07_21_174626_create_student_tbl_table', 2),
(3, '2018_07_25_152749_create_teachers_tbl_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `student_tbl`
--

CREATE TABLE `student_tbl` (
  `student_id` int(10) UNSIGNED NOT NULL,
  `student_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_roll` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_father_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_mother_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_admission_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_tbl`
--

INSERT INTO `student_tbl` (`student_id`, `student_name`, `student_roll`, `student_father_name`, `student_mother_name`, `student_email`, `student_phone`, `student_address`, `student_image`, `student_password`, `student_department`, `student_admission_year`) VALUES
(4, 'Hasan Mahmud', '12111', 'Abdul Hai', 'Rohima Akter', 'mahmud@gmail.com', '01845124841', 'dhaka,bangladeh', 'image/2wF5sp0EgaTTdXUEhqSu.jpg', 'e10adc3949ba59abbe56e057f20f883e', '1', '2018-07-02'),
(5, 'Faruk Khan', '1212', 'Hasin Khan', 'Hacina Bagom', 'faruk@gmail.com', '01745134589', 'dhaka,bangladesh', 'image/HCJP7P1qpuHmayWQji0p.jpg', 'd41d8cd98f00b204e9800998ecf8427e', '2', '2018-07-06'),
(6, 'Sakil Ahmed', '1213', 'Abu Ahmed', 'Aysa Ahmed', 'sakil@gmail.com', '015123698745', 'jossore', 'image/bHDXZEs8h2ttx9jMNzWZ.jpg', 'e10adc3949ba59abbe56e057f20f883e', '3', '2018-07-07'),
(7, 'Akas Molotra', '1214', 'Kobir Molotra', 'Sabina Molotra', 'akas@gmail.com', '01945123698', 'kulna,bangladesh', 'image/2kbnMirv9oGxz8kHExCS.jpg', 'e10adc3949ba59abbe56e057f20f883e', '4', '2018-07-12'),
(8, 'Bulbul Ahmed', '1215', 'Rohim Ahmed', 'Asma Ahmed', 'bulbul@gmail.com', '018451269872', 'comilla', 'image/EaEXEH3dfUnZjkuBV3YN.jpg', 'd41d8cd98f00b204e9800998ecf8427e', '5', '2018-07-21'),
(9, 'Abir Khan', '1216', 'Shahariar Khan', 'Sahida Khan', 'abir@gmail.com', '01878451236', 'chittagong,bangladesh', 'image/dvDu9B8HWFmWwOBfUql0.jpg', 'e10adc3949ba59abbe56e057f20f883e', '1', '2018-07-23'),
(10, 'Mosaraf Hossain', '1217', 'Shohel Hossain', 'Amina Akter', 'mosaraf@gmail.com', '015421548796', 'kisorgong,bangladesh', 'image/mfr9mV8RcXfDjQJcrZ9y.jpeg', 'd41d8cd98f00b204e9800998ecf8427e', '2', '2018-07-04'),
(11, 'Taman Khan', '1218', 'Al-Amin Khan', 'Aysmin khan', 'taman@gmail.com', '01748124578', 'Sharpur', 'image/5j93WnkPsI6EnccJYdXH.jpg', 'e10adc3949ba59abbe56e057f20f883e', '3', '2018-07-31'),
(12, 'Robiul Hasan', '1219', 'Mahmud hasan', 'Sruti Hasan', 'robiul@gmail.com', '01754123698', 'Munsigong', 'image/GEGyz1wacpINg2k4Szd8.jpg', 'd41d8cd98f00b204e9800998ecf8427e', '4', '2018-07-17'),
(13, 'Shiful Islam', '1210', 'Sohidul Islam', 'Tamanna Islam', 'shiful@gmail.com', '01845123698', 'coxbazer,bangladesh', 'image/0SqvKKJjX9GQKzEMwriu.jpg', 'e10adc3949ba59abbe56e057f20f883e', '5', '2018-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `teachers_tbl`
--

CREATE TABLE `teachers_tbl` (
  `teachers_id` int(10) UNSIGNED NOT NULL,
  `teachers_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers_tbl`
--

INSERT INTO `teachers_tbl` (`teachers_id`, `teachers_name`, `teachers_phone`, `teachers_address`, `teachers_department`, `teachers_image`, `created_at`, `updated_at`) VALUES
(1, 'sdfa', '35132', 'dsf', '1', 'image/b2ifzpvTXgMqnfLS8TOy.jpg', NULL, NULL),
(2, 'hasan', '015', 'feni', '3', 'image/ew3qIXNWN4iNG8cEsF4q.jpg', NULL, NULL),
(3, 'Salman Muktadi', '01512369874', 'dhaka,bangladesh', '5', 'image/E2KBw61PrzDjlqHeniz7.jpg', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_tbl`
--
ALTER TABLE `student_tbl`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `teachers_tbl`
--
ALTER TABLE `teachers_tbl`
  ADD PRIMARY KEY (`teachers_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student_tbl`
--
ALTER TABLE `student_tbl`
  MODIFY `student_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `teachers_tbl`
--
ALTER TABLE `teachers_tbl`
  MODIFY `teachers_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
