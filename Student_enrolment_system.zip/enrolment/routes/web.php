<?php
Route::get('/logout', 'AdminController@logout'); //logout
Route::get('/student_logout', 'AdminController@student_logout'); //logout
Route::get('/', function () {
	return view('student_login');
});
Route::get('/backend', function () {
	return view('admin.admin_login');
});
Route::post('/adminlogin', 'AdminController@login_dashboard');
Route::post('/studentlogin', 'AdminController@student_login_dashboard');
Route::get('/student_dashboard', 'AdminController@student_dashboard');

Route::get('/admin_dashboard', 'AdminController@admin_dashboard');
Route::get('/profile', 'AdminController@profile');
Route::get('/setting', 'AdminController@setting');
Route::get('/student_profile', 'AddstudentsController@studentprofile');

Route::get('/student_setting', 'AdminController@studentsetting');

Route::get('/addstudent', 'AddstudentsController@addstudent');
Route::post('/save_student', 'AddstudentsController@save_student');
Route::get('/allstudent', 'AllstudentsController@allstudent');
Route::get('/student_delete/{student_id}', 'AllstudentsController@studentdelete');
Route::get('/student_view/{student_id}', 'AllstudentsController@studentview');
Route::get('/student_edit/{student_id}', 'AllstudentsController@studentedit');
Route::post('/update_student/{student_id}', 'AllstudentsController@studentupdate');
Route::post('/student_own_update', 'AllstudentsController@studentownupdate');
Route::get('/studentview', 'AllstudentsController@studentview');
Route::get('/tutionfree', 'TutionController@tutionfree');
Route::get('/cse', 'CSEController@cse');
Route::get('/eee', 'EEEController@eee');
Route::get('/bba', 'BBAController@bba');
Route::get('/mba', 'MBAController@mba');
Route::get('/law', 'LAWController@law');
Route::get('/allfaculty', 'TeacherController@allfaculty');
Route::get('/addfaculty', 'TeacherController@addfaculty');
Route::post('/save_faculty', 'TeacherController@save_faculty');