<?php $__env->startSection('content'); ?>
     <div class="card">
            <div class="card-body">
              <h2 class="card-title">Data table</h2>
              <div class="row">
                <div class="col-12">
                  <table id="order-listing" class="table table-striped" style="width:100%;">
                    <thead>
                      <tr>
                          <th>Id</th>
                          <th>Student Name</th>
                          <th>Student Roll</th>
                          <th>Student Email</th>
                          <th>Student Phone</th>
                          <th>Student Address</th>
                          <th>Student Image</th>
                          <th>Student Department</th>
                          <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	<?php $__currentLoopData = $mba_student_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                          <td><?php echo e($view_student->student_id); ?></td>
                          <td><?php echo e($view_student->student_name); ?></td>
                          <td><?php echo e($view_student->student_roll); ?></td>
                          <td><?php echo e($view_student->student_email); ?></td>
                          <td><?php echo e($view_student->student_phone); ?></td>
                          <td><?php echo e($view_student->student_address); ?></td>
                          <td><img src="<?php echo e(URL::to($view_student->student_image)); ?>" height="50" width="70" style="border-radius: 50%;"></td>
                          <td>
                              <?php if($view_student->student_department == 1): ?>
                              <span class="label label-success"><?php echo e('CSE'); ?></span>
                              <?php elseif($view_student->student_department == 2): ?>
                              <span class="label label-primary"><?php echo e('EEE'); ?></span>
                              <?php elseif($view_student->student_department == 3): ?>
                              <span class="label label-warning"><?php echo e('BBA'); ?></span>
                              <?php elseif($view_student->student_department == 4): ?>
                              <span class="label label-info"><?php echo e('MBA'); ?></span>
                              <?php elseif($view_student->student_department == 5): ?>
                              <span class="label label-info"><?php echo e('LAW'); ?></span>
                              <?php else: ?>
                              <span class="label label-important"><?php echo e('NOT Defined'); ?></span>
                              <?php endif; ?>
                          </td>
                          <td>
                            <button class="btn btn-outline-primary">View</button>
                            <button class="btn btn-outline-warning">Edit</button>
                            <button class="btn btn-outline-danger">Delete</button>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>