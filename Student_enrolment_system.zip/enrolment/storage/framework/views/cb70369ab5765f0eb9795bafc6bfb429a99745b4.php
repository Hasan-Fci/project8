<?php
   function convert_dept($value){
   $values=[
        1=>'CSE',
        2=>'EEE',
        3=>'BBA',
        4=>'MBA',
        5=>'LAW',
   ];
   return $values[$value];
 }
?>
<?php $__env->startSection('content'); ?>
          <div class="row user-profile">
            <div class="col-lg-12 side-left">
              <div class="card mb-12">
                <div class="card-body avatar">
                  <h2 class="card-title">Info</h2>
                  <img src="<?php echo e(URL::to($student_profile->student_image)); ?>">
                  <p class="name"><?php echo e($student_profile->student_name); ?></p>
                  <a class="email" href="#"><?php echo e($student_profile->student_email); ?></a>
                  <a class="number" href="#"><?php echo e($student_profile->student_phone); ?></a>
                </div>
              </div>
              <div class="card mb-12">
                <div class="card-body overview">
                  <ul class="achivements">
                    <h5 style="color: red;">Feni Computer Institute,Feni</h5>
                  </ul>
                  <div class="wrapper about-user">
                    <h2 class="card-title mt-4 mb-3">About</h2>
                    <p>Student Total Information</p>
                  </div>
                  <div class="info-links">
                    <a class="website" href="https://www.bootstrapdash.com/">
                      <i class="icon-globe icon">Father Name</i>
                      <span style="font-family: vernada;font-size: 15px;"><?php echo e($student_profile->student_father_name); ?></span>
                    </a>
                    <a class="social-link" href="#">
                      <i class="icon-social-facebook icon">Mother Name</i>
                      <span style="font-family: vernada;font-size: 15px;"><?php echo e($student_profile->student_mother_name); ?></span>
                    </a>
                    <a class="social-link" href="#">
                      <i class="icon-social-linkedin icon">Address</i>
                      <span style="font-family: vernada;font-size: 15px;"><?php echo e($student_profile->student_address); ?></span>
                    </a>
                    <a class="social-link" href="#">
                      <i class="icon-social-linkedin icon">Student Roll</i>
                      <span style="font-family: vernada;font-size: 15px;"><?php echo e($student_profile->student_roll); ?></span>
                    </a>
                    <a class="social-link" href="#">
                      <i class="icon-social-linkedin icon">Student Department</i>
                      <span style="font-family: vernada;font-size: 15px;"><?php echo e(convert_dept($student_profile->student_department)); ?></span>
                    </a>
                    <a class="social-link" href="#">
                      <i class="icon-social-linkedin icon">Admission Year</i>
                      <span style="font-family: vernada;font-size: 15px;"><?php echo e($student_profile->student_admission_year); ?></span>
                    </a>
                  </div>  
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>