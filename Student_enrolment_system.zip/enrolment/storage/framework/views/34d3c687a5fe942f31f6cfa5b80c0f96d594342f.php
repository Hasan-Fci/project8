<?php $__env->startSection('content'); ?>
     <div class="col-12 col-lg-6 grid-margin">
	      <div class="card">
	          <div class="card-body">
	              <h2 class="card-title">Add Faculty</h2>

                   <p class="alert-success"><?php 
                        $message = Session::get('message');
                        if ($message) {
                        	echo $message;
                        	Session::put('message', null);
                        }
                    ?></p>

	              <form class="forms-sample" method="post" action="<?php echo e(URL::to('/save_faculty')); ?>" enctype="multipart/form-data">
	              	<?php echo e(csrf_field()); ?>

	              	  <div class="form-group">
	                      <label for="exampleInputEmail1">Faculty Name</label>
	                      <input type="text" class="form-control p-input" name="teachers_name" aria-describedby="emailHelp" placeholder="Enter Faculty Name">
	                  </div>
	                  <div class="form-group">
	                      <label for="exampleInputPassword1">Faculty Phone</label>
	                      <input type="password" class="form-control p-input" name="teachers_phone" placeholder="Faculty Phone">
	                  </div>
	                  <div class="form-group">
	                      <label for="exampleTextarea">Faculty Address</label>
	                      <textarea class="form-control p-input" name="teachers_address" rows="3" placeholder="Faculty Address"></textarea>
	                  </div>
	                  <div class="form-group">
	                      <label for="exampleInputPassword1">Faculty Department</label>
	                      <select name="teachers_department" class="form-control p-input">
	                      	  <option value="1">CSE</option>
	                      	  <option value="2">EEE</option>
	                      	  <option value="3">BBA</option>
	                      	  <option value="4">MBA</option>
	                      	  <option value="5">LAW</option>
	                      </select>
	                  </div>
	                  <div class="form-group">
                                  <label>Upload Image</label>
                                  <div class="row">
                                    <div class="col-12">
                                      <label for="exampleInputFile2" class="btn btn-outline-primary btn-sm"><i class="mdi mdi-upload btn-label btn-label-left"></i>Browse</label>
                                      <input type="file" name="teachers_image" class="form-control-file" id="exampleInputFile2" aria-describedby="fileHelp">
                                    </div>
                                  </div>
                              </div>
	                  
	                  <button type="submit" name="submit" class="btn btn-success btn-block">Add Faculty</button>
	              </form>
	          </div>
	      </div>
	  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>