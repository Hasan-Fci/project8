<?php $__env->startSection('content'); ?>
          <div class="card">
            <div class="card-body">
              <h2 class="card-title">Data table</h2>

<p class="alert-success"><?php 
     $message = Session::get('message');
     if ($message) {
       echo $message;
       Session::put('message',null);
     }
 ?></p>

              <div class="row">
                <div class="col-12">
                  <table id="order-listing" class="table table-striped" style="width:100%;">
                    <thead>
                      <tr>
                          <th>Faculty Name</th>
                          <th>Faculty Phone</th>
                          <th>Faculty Address</th>
                          <th>Faculty Image</th>
                          <th>Faculty Department</th>
                          <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $all_teacher_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                      <tr>
                      	<td><?php echo e($view_teacher->teachers_name); ?></td>
                      	<td><?php echo e($view_teacher->teachers_phone); ?></td>
                      	<td><?php echo e($view_teacher->teachers_address); ?></td>
                      	<td><img src="<?php echo e(URL::to($view_teacher->teachers_image)); ?>" height="50" width="60" style="border-radius: 50%"></td>
                      	<td>
                              <?php if($view_teacher->teachers_department == 1): ?>
                              <span class="label label-success"><?php echo e('CSE'); ?></span>
                              <?php elseif($view_teacher->teachers_department == 2): ?>
                              <span class="label label-primary"><?php echo e('EEE'); ?></span>
                              <?php elseif($view_teacher->teachers_department == 3): ?>
                              <span class="label label-warning"><?php echo e('BBA'); ?></span>
                              <?php elseif($view_teacher->teachers_department == 4): ?>
                              <span class="label label-info"><?php echo e('MBA'); ?></span>
                              <?php elseif($view_teacher->teachers_department == 5): ?>
                              <span class="label label-info"><?php echo e('LAW'); ?></span>
                              <?php else: ?>
                              <span class="label label-important"><?php echo e('NOT Defined'); ?></span>
                              <?php endif; ?>
                          </td>
                          <td>
                            <a href="<?php echo e(URL::to('')); ?>"><button class="btn btn-outline-primary">View</button></a>
                            <a href="<?php echo e(URL::to('')); ?>"><button class="btn btn-outline-warning">Edit</button></a>
                            <a href="<?php echo e(URL::to('')); ?>" id="delete"><button class="btn btn-outline-danger">Delete</button></a>
                          </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>