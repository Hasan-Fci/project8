<?php $__env->startSection('content'); ?>
     <div class="col-12 col-lg-6 grid-margin">
	      <div class="card">
	          <div class="card-body">
	              <h2 class="card-title">Add Student</h2>

                   <p class="alert-success"><?php 
                        $message = Session::get('message');
                        if ($message) {
                        	echo $message;
                        	Session::put('message', null);
                        }
                    ?></p>

	              <form class="forms-sample" method="post" action="<?php echo e(URL::to('/student_own_update')); ?>">
	              	<?php echo e(csrf_field()); ?>

	                  <div class="form-group">
	                      <label for="exampleInputPassword1">Student Phone</label>
	                      <input type="number" class="form-control p-input" name="student_phone" value="<?php echo e(($student_profile->student_phone)); ?>">
	                  </div>
	                  <div class="form-group">
	                      <label for="exampleTextarea">Student Address</label>
	                      <input class="form-control p-input" name="student_address" rows="3" value="<?php echo e(($student_profile->student_address)); ?>">
	                  </div>
	                  <div class="form-group">
	                      <label for="exampleInputPassword1">Student Password</label>
	                      <input type="password" class="form-control p-input" name="student_password" value="<?php echo e(($student_profile->student_password)); ?>">
	                  </div>
	                  <button type="submit" name="submit" class="btn btn-success btn-block">Update</button>
	              </form>
	          </div>
	      </div>
	  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>