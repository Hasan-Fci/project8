<?php

namespace App\Http\Controllers;
use DB;
class LAWController extends Controller {
	public function law() {
		$lawstudent = DB::table('student_tbl')
                      ->where(['student_department'=>5])
		              ->get();
		$manage_student = view('admin.law')
							->with('law_student_info',$lawstudent);
		return view('layout')->with('law',$manage_student);
		return view('admin.law');
		//print_r($bbastudent);
		//return view('admin.law');
	}
}
