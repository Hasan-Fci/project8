<?php

namespace App\Http\Controllers;
use DB;
class BBAController extends Controller {
	public function bba() {
		$bbastudent = DB::table('student_tbl')
                      ->where(['student_department'=>3])
		              ->get();
		$manage_student = view('admin.bba')
							->with('bba_student_info',$bbastudent);
		return view('layout')->with('bba',$manage_student);
		return view('admin.bba');
		//print_r($bbastudent);

		return view('admin.bba');
	}
}
