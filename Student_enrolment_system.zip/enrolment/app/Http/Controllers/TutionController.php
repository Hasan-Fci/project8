<?php

namespace App\Http\Controllers;

class TutionController extends Controller {
	public function tutionfree() {
		return view('admin.tutionfree');
	}
}
