<?php

namespace App\Http\Controllers;
use DB;
class CSEController extends Controller {
	public function cse() {
		$csestudent = DB::table('student_tbl')
                      ->where(['student_department'=>1])
		              ->get();
		$manage_student = view('admin.cse')
							->with('cse_student_info',$csestudent);
		return view('layout')->with('cse',$manage_student);
		return view('admin.cse');              
		//return view('admin.cse');
		//print_r($csestudent);
	}
}
