<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Redirect;
use Session;
session_start();
class AllstudentsController extends Controller {
	public function allstudent() {
		$allstudent_info = DB::table('student_tbl')->get();
		$manage_student = view('admin.allstudent')->with('all_student_info', $allstudent_info);
		return view('layout')->with('allstudent', $manage_student);
		//return view('admin.allstudent');
	}
	public function studentdelete($student_id){
 		DB::table('student_tbl')->where('student_id',$student_id)->delete();
 		return Redirect::to('/allstudent');

		//echo "success";
	}
	public function studentview($student_id){
		$studentview = DB::table('student_tbl')
		              ->select('*')
		              ->where('student_id', $student_id)
		              ->first();
  		$manage_student = view('admin.view')
  		                 ->with('student_profile', $studentview);
         return view('layout')
                          ->with('view', $manage_student);
		 //print_r($studentview);
		//return view('admin.view');
	}
	public function studentedit($student_id){
        $studentedit = DB::table('student_tbl')
                       ->select('*')
                       ->where('student_id',$student_id)
                       ->first();
                       /*echo "<pre>";
                       print_r($studentedit);
                       echo "</pre>";*/
        $manage_student = view('admin.student_edit')
        					->with('student_profile',$studentedit);
		return view('layout')
					->with('student_edit', $manage_student);
	}
	public function studentupdate(Request $request, $student_id){
       //print_r($student_id);
		$data = array();
		$data['student_name'] = $request->student_name;
		$data['student_roll'] = $request->student_roll;
		$data['student_father_name'] = $request->student_father_name;
		$data['student_mother_name'] = $request->student_mother_name;
		$data['student_email'] = $request->student_email;
		$data['student_phone'] = $request->student_phone;
		$data['student_address'] = $request->student_address;
		$data['student_admission_year'] = $request->student_admission_year;
		DB::table('student_tbl')->where('student_id', $student_id)->update($data);
		session::put('message', 'Student Update Successfully!!');
		return Redirect::to('/allstudent');
	}
	public function studentownupdate(Request $request){
       //print_r($student_id);
		$student_id = Session::get('student_id');
		$data = array();
		$data['student_phone'] = $request->student_phone;
		$data['student_address'] = $request->student_address;
		$data['student_password'] = $request->student_password;
		DB::table('student_tbl')->where('student_id', $student_id)->update($data);
		session::put('message', 'Student Update Successfully!!');
		return Redirect::to('/student_setting');
	}
}
