@extends('student_layout');
@section('content')
            <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">All Student</h2>
                @php
                    $student = DB::table(
                    'student_tbl')->count('student_id');
                @endphp
                <h2 style="text-align: center;font-size: 52px;">{{$student}}</h2>
              </div>
              <div class="dashboard-chart-card-container">
                <div id="dashboard-card-chart-1" class="card-float-chart"></div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">All Teacher</h2>
                @php
                    $faculty = DB::table(
                    'teachers_tbl')->count('teachers_id');
                @endphp
                <h2 style="text-align: center;font-size: 52px;">{{$faculty}}</h2>
              </div>
              <div class="dashboard-chart-card-container">
                <div id="dashboard-card-chart-2" class="card-float-chart"></div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Tution Free</h2>
                <h3 style="text-align: center;font-size: 46px;">Monthly 5000tk</h3>
              </div>
              <div class="dashboard-chart-card-container">
                <div id="dashboard-card-chart-3" class="card-float-chart"></div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-3 grid-margin">
            <div class="card">
              <div class="card-body">
                <h2 class="card-title">Revenue</h2>
                <h2 style="text-align: center;font-size: 52px;">revenue</h2>
              </div>
              <div class="dashboard-chart-card-container">
                <div id="dashboard-card-chart-4" class="card-float-chart"></div>
              </div>
            </div>
          </div>
           
@endsection